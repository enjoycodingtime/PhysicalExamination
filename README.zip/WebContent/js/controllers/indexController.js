'use strict';

angular.module('peApp').controller('indexCtrl',
		function($scope, $http, $location) {

		});