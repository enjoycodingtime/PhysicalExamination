'use strict';

angular.module('peApp').controller('manageHomeCtrl',
		function($scope, $http, $location) {

		});